console.log("page loaded...");

// var x = document.getElementById("birds"); 

// function play(x) { 
//   x.play(); 
// } 

// function pause(x) { 
//   x.pause(); 
// }



