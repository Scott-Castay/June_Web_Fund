
var numA = 9
var numB = 12
var numC = 9

function counter()
 {
    console.log(numA)
    
    numA++
    document.querySelector("#counter").innerHTML = numA; 
    

}
function counter2()
 {
    console.log(numB)
    
    numB++
    document.querySelector("#counter2").innerHTML = numB ;

}
function counter3()
 {
    console.log(numC)

    numC++ 
    document.querySelector("#counter3").innerHTML = numC ;
}


